function showAbout() {
    var aboutContent = document.getElementById("aboutContent");
    var aboutParagraph = document.getElementById("aboutParagraph");
  
    // Show the about content
    aboutContent.style.display = "block";
  
    // Optionally, you can modify the paragraph text here
    // aboutParagraph.innerText = "New paragraph text";
  }
  