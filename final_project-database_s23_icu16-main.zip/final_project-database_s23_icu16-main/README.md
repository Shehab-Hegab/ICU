# final_project-database_s23_icu16
Team 16_ICU project


Team Members:


Ahmed Khaled              Sec:1   BN:2


Kyrillos Emad Barakat     Sec 2   Bn 7


Shehab Mohamed Ibrahim   Sec:1    BN:33


Hussein Mohamed          Sec:1    BN:19



Mohamed Gamal            Sec:1    BN:48



Mohamed Aziz          Sec:1    BN:49


We Have in this Project 2 folders one contain backend called (database)
and the other contain front end  called(Login-page).


Please open the database files in vscode and use npm i express , npm i cors , npm run dev (we used xampp and we started apache and mysql).


Then use npm run dev 


The database we used was on localhost and we tried to share it but we failed.

Then open the login files in vscode and from index.html you can start the website by go live.


In the login page on the website we can access through only some users from Java script code like: 

UserName:Ahmed Khaled , password:123


If you try another user or password it will not go to another page.


The second page which will go after index.html is welcome page:


You have burger style bar and from it details of (Contact us (send to my mail message), Doctors(show doctors details) , Nurses(show Nurses details)).

We have 3 button in the welcome page:


1.Add patient (you will go to form when complete it it direct go to check patient page data).


2.Check patient(show all details of patient).


3.Statstics (show rooms,capacity,room number).

